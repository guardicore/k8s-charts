# CHANGELOG

### 1.7.0
- [GC-137046] Improve enforcementCni logic #2
- [GC-138795] Move debug switch under global values
- [GC-138794] Minor tidy ups
- [GC-137571] Remove residual gc-guest-agent and gc-kube-enforce serviceAccount create field

### 1.6.0
- [GC-137679] Add extra envs to gc-kube-enforce
- [GC-137670] Tidy up values.yaml
- [GC-137571] Remove ServiceAccounts creation configurability
- [GC-137559] Improve http proxy configuration values validation
- [GC-137184] Improve aggregatorEndpoints validation logic
- [GC-137173] Hardcode gcProfile to default
- [GC-137046] Improve enforcementCni logic
- [GC-136808] Rename and improve public/private image registry logic
- [GC-136782] Improve appVersion logic

### 1.5.0
- [GC-136160] Support HTTP proxy configuration on GC guest-agent and kube-enforce

### 1.4.0
- [GC-136059] Replace sslServer and sslPort with sslAddresses and rename

### 1.3.0
- [GC-116152] Support reporting node info in kube-enforce

### 1.2.0
- [GC-125135] - Support SNAT visibility with Cilium eBPF IP Masquerading
                Specifically in the helm charts - mount /sys to /host/sys not only for amazonvpc CNI

### 1.1.0
- Removed the deprecated gc-kube-inventory chart
- Removed the deprecated notification port configuration

### 1.0.0
- First helm-chart release version
