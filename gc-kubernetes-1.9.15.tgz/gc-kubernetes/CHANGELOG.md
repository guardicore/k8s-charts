# CHANGELOG

### 1.9.15
- [GC-182003] gc-guest-agent: add a `priorityClass` to the agent DaemonSet, so agent pods can preempt regular workloads instead of staying Pending on nodes whose CPU/memory is fully requested. On by default: the chart creates `gc-guest-agent-critical` (value 900000000); set `priorityClass.create: false` with `name` to use an existing class (e.g. `system-node-critical`)
  - **Upgrade note:** on nodes without room for the agent, the scheduler now evicts lower-priority pods to place it. The DaemonSet pods are also rolled once to pick up the class
- [GC-182003] gc-guest-agent: make the container `resources` configurable (`gc-guest-agent.resources`); defaults are unchanged (requests 100m/500Mi, limits 1000m/2000Mi)
- [GC-182003] gc-kube-enforce, gc-kube-inventory: add the same `priorityClass` (on by default, `gc-kube-enforce-critical` / `gc-kube-inventory-critical`, value 900000000). Equal priority classes never preempt each other, so the agent cannot evict these single-replica pods to place itself, and regular workloads cannot evict them either
  - **Upgrade note:** gc-kube-enforce and gc-kube-inventory are rolled once to pick up their class and, like the agent, can now evict lower-priority pods when rescheduled onto a full node
- [GC-182003] gc-dns-proxy: add `priorityClass.create` (default `true`); set it to `false` with `name` to use an existing class instead of creating `gc-dns-proxy-critical`

### 1.9.14
- [GC-170365] gc-kube-enforce: add `global.features.enforcement.ovnSafeApply`, which uses two-slot NetworkPolicy naming on OVN-Kubernetes to avoid dropping allowed traffic on policy update. On by default; set `enabled: false` to update objects in place instead
- [GC-170365] `ovnSafeApply` needs a gc-dns-proxy from the same release: an older gc-dns-proxy ignores the `guardicore/converging-until` / `guardicore/converging-replaces-uid` annotations gc-kube-enforce stamps on the incoming slot and intersects the two slots of a converging policy, so an FQDN whose IPs fully turn over intersects to nothing mid-flip, and every query for that FQDN issued during a flip's grace window blocks for up to 5 s on that node until the proxy pod is rolled. Roll gc-dns-proxy alongside gc-kube-enforce, and do not pin `gc-dns-proxy.appVersion` below it on OVN clusters

### 1.9.13
- [GC-177465] gc-dns-proxy: auto-inject is now the default (`global.features.enforcement.fqdn.autoInject: true`)
  - **Upgrade note:** existing manual-mode installs (KubeDNS forwards to the gc-dns-proxy Service) must either revert the KubeDNS change before upgrading, or set `autoInject: false` to stay in manual mode. GKE is supported in manual mode only: set `autoInject: false`.

### 1.9.12
- [GC-173696] gc-kube-inventory: honor `global.features.httpProxy` (http_proxy/https_proxy/no_proxy env), so inventory can reach the aggregator through an explicit HTTP proxy

### 1.9.11
- [GC-170395] gc-kube-inventory: add a `securityContext` with `seLinuxOptions.type: spc_t` so the pod can write the `/var/log/guardicore` hostPath on OpenShift/RHCOS (SELinux), and add the Pod Security Admission `privileged` labels to the chart-created namespace (matching the v1 chart) so that type is admitted

### 1.9.10
- [GC-170395] Port gc-kube-inventory memory-remediation Helm chart changes into v2 chart: `GOGC` env (default 50), `startupProbe` retargeted from `/readyz` to `/startupz`, and a templated `resources` block

### 1.9.9
- [GC-164233] README: document `createNamespace`, the chart-managed secrets, and installing the release outside of `global.gcNamespace`

### 1.9.8
- [GC-164233] Add chart-managed secrets via the `secrets` values, and optional namespace creation via `createNamespace`
- [GC-164233] NOTES.txt: report the release namespace, not `global.gcNamespace`, in the `helm get values` and `helm uninstall` hints
- [GC-162363] Fix TLS CA hooks race by running them on post-install instead of pre-install

### 1.9.7
- [GC-159739] gc-dns-proxy: fix auto-inject on OpenShift and on multi-node clusters

### 1.9.6
- [GC-162365] Fix gc-deploy-role calico RBACs for uninstall job

### 1.9.5
- [GC-168151] Disable gc-dns-proxy metrics server by default

### 1.9.4
- [GC-164233] Remove unnecessary labels from gc-pre-delete job

### 1.9.3
- [GC-159503] Port gc-kube-inventory Helm chart changes into v2 chart

### 1.9.2
- [GC-162363] Fix securityContexts in gc-dns-proxy deployment's containers
- [GC-162363] Fix annotations in gc-dns-proxy serviceAccount

### 1.9.1
- [GC-162363] Fix httpProxyEndpoint helper failing when global.features.httpProxy.port is set as a number

### 1.9.0
- [GC-163707] Prepare for publishing v1.9.0 to public repo

### 1.8.17
- [GC-162363] Fix issues reported by the customer, and some other improvements
- [GC-160747] Add gc-kube-inventory Helm chart
- [GC-162365] Reduce k8s RBACs to minimal
- [GC-163599] Fix wrong apiGroup in gc-guest-agent's RBACs

### 1.8.16
- [GC-159902] adjust replica configuration and high availability for gc-dns-proxy

### 1.8.15
- [GC-151938] Add autoInject field for DaemonSet mode with DNS injector sidecar on managed platforms

### 1.8.14
- [GC-00000] fixing readme

### 1.8.13
- [GC-00000] Promoting the detailed README.md

### 1.8.11
- [GC-151908] add an automatic policy_propagation_delay_ms configuration based on CNI type

### 1.8.10
- [GC-155195] set gc-deployment entrypoint command

### 1.8.9
- [GC-155195] fail fast if root CA creation hook is failing

### 1.8.8
- [GC-154956] Add BPF mode support for reveal agent, and create a custom high-priority PriorityClass

### 1.8.7
- [GC-138287] Fix fqdn gc-dns-proxy ovn configurations

### 1.8.6
- [GC-128894] Add TLS support for FQDN HTTP endpoints with automatic CA generation and user-provided CA options
- [GC-135797] Add ServiceAccount authentication support for FQDN HTTP endpoints

### 1.8.5
- [GC-150830] Fix example-values.yaml field names and align sub-chart defaults

### 1.8.4
- [GC-128792] Add gc-dns-proxy metrics service
- [GC-144965] Export gc-dns-proxy configurations as advanced options
- [GC-122515] Docs – edit the k8s API certificate command in NOTES.txt

### 1.8.3
- [GC-144393] Add probes toggle configuration

### 1.8.2
- [GC-140323] Add kube-enforce fqdn ip storage configurations

### 1.8.1
- [GC-138287] Fix fqdn gc-dns-proxy conditions

### 1.8.0
- [GC-138287] Add fqdn gc-dns-proxy yamls

### 1.7.0
- [GC-137046] Improve enforcementCni logic #2
- [GC-138795] Move debug switch under global values
- [GC-138794] Minor tidy ups
- [GC-137571] Remove residual gc-guest-agent and gc-kube-enforce serviceAccount create field

### 1.6.0
- [GC-137679] Add extra envs to gc-kube-enforce
- [GC-137670] Tidy up values.yaml
- [GC-137571] Remove ServiceAccounts creation configurability
- [GC-137559] Improve http proxy configuration values validation
- [GC-137184] Improve aggregatorEndpoints validation logic
- [GC-137173] Hardcode gcProfile to default
- [GC-137046] Improve enforcementCni logic
- [GC-136808] Rename and improve public/private image registry logic
- [GC-136782] Improve appVersion logic

### 1.5.0
- [GC-136160] Support HTTP proxy configuration on GC guest-agent and kube-enforce

### 1.4.0
- [GC-136059] Replace sslServer and sslPort with sslAddresses and rename

### 1.3.0
- [GC-116152] Support reporting node info in kube-enforce

### 1.2.0
- [GC-125135] - Support SNAT visibility with Cilium eBPF IP Masquerading
                Specifically in the helm charts - mount /sys to /host/sys not only for amazonvpc CNI

### 1.1.0
- Removed the deprecated gc-kube-inventory chart
- Removed the deprecated notification port configuration

### 1.0.0
- First helm-chart release version
