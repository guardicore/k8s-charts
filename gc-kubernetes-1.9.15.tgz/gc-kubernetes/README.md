# Akamai Guardicore Kubernetes Helm Chart

This guide provides instructions for installing the `gc-kubernetes` Helm chart to deploy Guardicore components on your Kubernetes cluster.

## Prerequisites

Before installing the Helm chart, ensure you have:

- **Helm v3.12+** installed
- **Kubernetes cluster** with `kubectl` configured with `cluster-admin` access
- **Installation password** - from Guardicore UI
- **Access to one Aggregator** endpoint

---

## Step 1: Create Namespace _(optional)_

The chart can create the namespace for you, set `createNamespace` to `true` and skip this step:

```yaml
createNamespace: true
```

Create the `guardicore` namespace _(or your custom namespace)_ yourself only if you want to manage it outside of the chart, or if the Helm release itself will live in it:

```bash
kubectl create namespace guardicore \
  --dry-run=client -o yaml | kubectl apply -f -
```

> **Note:** If using a custom namespace, ensure you update the namespace name in all subsequent steps.
>
> **Note:** Leave `createNamespace` as `false` if the namespace already exists, the chart cannot take ownership of a namespace it did not create.

---

## Step 2: Add the Helm Repository

1. Add the Guardicore Helm repository
    ```bash
    helm repo add k8s-charts https://guardicore.github.io/k8s-charts/
    ```
2. Update repository indexes
    ```bash
    helm repo update
    ```
3. List available chart versions
    ```bash
    helm search repo k8s-charts/gc-kubernetes --versions
    ```
4. Download a copy of the chart if you wish to review it's content or modify the values.yaml file:
    ```bash
    helm pull k8s-charts/gc-kubernetes --untar
    ```


### Chart Verification

Guardicore Helm charts are signed for integrity verification.

1. Download the public key `akamai-support-public-key.gpg` from the repository.
2. Verify the chart before installation:
    ```bash
    helm fetch --verify k8s-charts/gc-kubernetes \
      --version {x.x.x} \
      --keyring "<PATH_TO_akamai-support-public-key.gpg>"
    ```

Successful verification output:
```
Signed by: Akamai Support <support@akamai.com>
Using Key With Fingerprint: 7A0D7DEDE7FCB2B8538C1A08A09DE238B0740BF0
Chart Hash Verified: sha256:...
```

---

## Step 3: Create Required Secrets

> **Note:** A list of information that needs to be gathered for the following steps:
> 1. `UI_UM_PASSWORD` - installation password from Guardicore UI
> 2. `AGGREGATOR_ENDPOINT` - one accessible Aggregator endpoint in the following supported formats:<br>&emsp;`ip`, `FQDN`, `ip:port` or `FQDN:port`<br>_(default port is 443)_

Three secrets are needed, the installation password, the Aggregator CA certificate and the Guardicore image registry auth JSON.

First gather the two files in [3.1](#31-download-the-ca-certificate) and [3.2](#32-obtain-the-image-registry-auth-json), then provide all three in one of two ways:

- [Option A: Let the chart create the secrets](#option-a-let-the-chart-create-the-secrets)
- [Option B: Create the secrets with kubectl](#option-b-create-the-secrets-with-kubectl)

> **Warning:** Use one option per secret, not both. Helm refuses to install a chart that would take over an already existing resource, and the install fails with an `invalid ownership metadata` error.

### 3.1 Download the CA Certificate

Download the CA certificate from the Aggregator using the URL `https://<AGGREGATOR_ENDPOINT>/guardicore-cas-chain-file.pem`, _on linux it would look something like:_
```bash
wget https://<AGGREGATOR_ENDPOINT>/guardicore-cas-chain-file.pem \
  --no-check-certificate \
  -O "<PATH_TO_guardicore_cas_chain_file.pem>"
```

### 3.2 Obtain the Image Registry Auth JSON

Guardicore images are stored in a private registry.

> **Note:** If you are using a custom image registry for Guardicore images refer to [this](#using-a-custom-image-registry) section.

Obtain the Guardicore image registry auth JSON according to the management type:
1. For a SaaS management, download it from the Aggregator using the URL `https://<AGGREGATOR_ENDPOINT>/kubernetes/docker_registry_auth.json`, CA certificate and `<UI_UM_PASSWORD>`, _on linux it would look something like:_
    ```bash
    wget https://<AGGREGATOR_ENDPOINT>/kubernetes/docker_registry_auth.json \
      --ca-certificate "<PATH_TO_guardicore_cas_chain_file.pem>" \
      --http-user gc-installation \
      --http-passwd "<UI_UM_PASSWORD>"
      -O "<PATH_TO_guardicore_registry_auth.json>"
    ```
2. For an on-prem management, the Guardicore image registry auth JSON should be supplied by Akamai Customer Support.

### Option A: Let the Chart Create the Secrets

Set the matching `secrets` values, and the chart creates each secret under `global.gcNamespace`:

```yaml
secrets:
  gcUiUmPassword: "<UI_UM_PASSWORD>"
  gcCaCert: |
    -----BEGIN CERTIFICATE-----
    ...
    -----END CERTIFICATE-----
  gcPrivateImageRegistryAuth: |
    {"auths": {...}}
```

Or straight from the command line, _on linux it would look something like:_

```bash
helm install gc-app k8s-charts/gc-kubernetes \
  --set-literal secrets.gcUiUmPassword="<UI_UM_PASSWORD>" \
  --set-file secrets.gcCaCert="<PATH_TO_guardicore_cas_chain_file.pem>" \
  --set-file secrets.gcPrivateImageRegistryAuth="<PATH_TO_guardicore_registry_auth.json>"
```

Any value left empty is skipped, so the two options can be mixed, for example a chart-managed password alongside an image pull secret created with `kubectl`.

### Option B: Create the Secrets with kubectl

1. Create the `guardicore-ui-secret` secret using `<UI_UM_PASSWORD>`:
    ```bash
    kubectl create secret generic guardicore-ui-secret \
      --namespace=guardicore \
      --from-literal=installation_password="<UI_UM_PASSWORD>" \
      --dry-run=client -o yaml | kubectl apply -f -
    ```
2. Create the `guardicore-cas-chain-secret` secret using the CA certificate from [3.1](#31-download-the-ca-certificate):
    ```bash
    kubectl create secret generic guardicore-cas-chain-secret \
      --namespace=guardicore \
      --from-file=guardicore_cas_chain_file.pem="<PATH_TO_guardicore_cas_chain_file.pem>" \
      --dry-run=client -o yaml | kubectl apply -f -
    ```
3. Create the `guardicore-registry-secret` image pull secret using the auth JSON from [3.2](#32-obtain-the-image-registry-auth-json):
    ```bash
    kubectl create secret generic guardicore-registry-secret \
      --namespace=guardicore \
      --type=kubernetes.io/dockerconfigjson \
      --from-file=.dockerconfigjson="<PATH_TO_guardicore_registry_auth.json>" \
      --dry-run=client -o yaml | kubectl apply -f -
    ```

#### Using a custom image registry

If you are using a custom image registry that requires authentication with a secret, create the relevant secret under the `guardicore` namespace and reference it in the Helm chart:

> **Note:** Refer to Guardicore docs for a guide to obtain images if you haven't done so already.

```yaml
global:
  imagePullSecrets:
    - name: <YOUR_SECRET_NAME>
```

### Verify Secrets

> **Note:** Chart-managed secrets are only created by `helm install`, verify them after Step 5.

```bash
kubectl get secrets -n guardicore
```

Expected output:

```bash
NAME                          TYPE                             DATA   AGE
guardicore-cas-chain-secret   Opaque                           1      17m
guardicore-registry-secret    kubernetes.io/dockerconfigjson   1      17m
guardicore-ui-secret          Opaque                           1      17m
```

---

## Step 4: Configure Values

In the `values.yaml` file or using `--set` flags.

> **Note:** For a working copy of values.yaml from the chart defaults, run:
> ```bash
> helm show values k8s-charts/gc-kubernetes > values.yaml
> ```

### Mandatory Values

| Key | Description | Default |
|-----|-------------|---------|
| `aggregatorEndpoints` | List of Aggregator endpoints in the following supported formats:<br>&emsp;`ip`, `FQDN`, `ip:port` or `FQDN:port`<br>_(default port is 443)_ | *(required)* |
| `global.appVersion` | Default image tag applied to all components unless overridden | *(required)* |

> **Note:** Default mode is reveal only, to enable enforcement:
> 1. toggle `global.features.enforcement.enabled` to `true`
> 2. set `global.features.enforcement.cni` to one of the following supported CNIs:<br>&emsp;`calico`, `ovn`, `azurecni`, `amazonvpc` or `cilium`

### Example values.yaml

```yaml
aggregatorEndpoints:
  - "172.16.100.50"
  - "172.16.100.51:8443"

global:
  appVersion: "v54.3.0-06486-fe331eb"
```

---

## Step 5: Install the Helm Chart

> **Note:** `--namespace` only selects where the Helm release record is stored, the Guardicore components are always deployed to `global.gcNamespace`. Keeping the release out of the `guardicore` namespace is what allows the chart to create and own that namespace, see [Step 1](#step-1-create-namespace-optional).

### Option A: Using values.yaml

```bash
helm install gc-app k8s-charts/gc-kubernetes \
  -f values.yaml \
  --namespace default
```

### Option B: Using --set flags

_on linux it would look something like:_
```bash
export AGGREGATOR_ENDPOINT_0="172.16.100.50"
export AGGREGATOR_ENDPOINT_1="172.16.100.51:8443"
export APP_VERSION="v54.3.0-06486-fe331eb"

helm install gc-app k8s-charts/gc-kubernetes \
  --version {x.x.x} \
  --namespace default \
  --set aggregatorEndpoints[0]="$AGGREGATOR_ENDPOINT_0" \
  --set aggregatorEndpoints[1]="$AGGREGATOR_ENDPOINT_1" \
  --set global.appVersion="$APP_VERSION"
```

---

## Uninstall

1. Uninstall the Helm Chart, _(might take some time)_
    ```bash
    helm uninstall gc-app --namespace default --wait
    ```
    > **Note:** If the chart created the namespace, this removes it as well.
2. Delete the `guardicore` namespace, only if you created it yourself in [Step 1](#step-1-create-namespace-optional)
    ```bash
    kubectl delete namespace guardicore
    ```
3. Remove the Guardicore Helm repository
    ```bash
    helm repo remove k8s-charts
    ```
    verify it's gone
    ```bash
    helm repo list
    ```
4. Update repository indexes
    ```bash
    helm repo update
    ```

---

## Support

For issues or questions, contact Akamai Customer Support.
