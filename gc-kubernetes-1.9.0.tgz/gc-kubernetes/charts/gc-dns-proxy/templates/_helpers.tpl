{{- define "gc-dns-proxy.extraConfig" -}}
{{/*
Sort keys before rendering because Go map iteration order is non-deterministic.
Without sorting, identical values can render in different orders between Helm runs,
causing unnecessary manifest diffs and triggering needless pod rollouts.
*/}}
{{- range $name := (.Values.extraPluginConfigs | keys | sortAlpha) }}
  {{- $value := index $.Values.extraPluginConfigs $name }}
  {{- printf "%s %v" $name $value | nindent 12 }}
{{- end }}
{{- end -}}

{{- define "policyPropagationDelayMs" -}}
{{- if not (kindIs "invalid" .Values.policyPropagationDelayMs) -}}
{{- .Values.policyPropagationDelayMs -}}
{{- else if eq (include "enforcementCni" .) "ovn" -}}
1000
{{- end -}}
{{- end -}}

{{- define "injectorImageTag" -}}
{{- $imageTag := (.Values.injector.appVersion | default .Values.appVersion | default .Values.global.appVersion) -}}
{{- required "At least one of injector.appVersion, gc-dns-proxy.appVersion, or global.appVersion must be set" $imageTag -}}
{{- end -}}

{{- define "gc-dns-proxy.injectorArgs" -}}
{{- if .Values.injector.extraArgs }}
args:
{{/*
Sort keys before rendering because Go map iteration order is non-deterministic.
Without sorting, identical values can render in different orders between Helm runs,
causing unnecessary manifest diffs and triggering needless pod rollouts.
*/}}
{{- range $flag := (.Values.injector.extraArgs | keys | sortAlpha) }}
  {{- $value := index $.Values.injector.extraArgs $flag }}
- --{{ $flag }}={{ $value }}
{{- end }}
{{- end }}
{{- end -}}
