# Configure OpenShiftDNS to Forward DNS Traffic via Guardicore DNS Proxy

This guide walks you through manually configuring the OpenShiftDNS to forward DNS traffic through the Guardicore DNS Proxy on OpenShift.

## Prerequisites

Before configuring the OpenShiftDNS, ensure you have:

- **gc-kubernetes** Helm chart installed with `global.features.enforcement.fqdn.enabled` toggled to `true`

---

## Step 1: Get the ClusterIP of the Guardicore DNS Proxy service

Obtain the `<GC_DNS_PROXY_SERVICE_IP>` by running:

```bash
oc get service -n guardicore gc-dns-proxy \
  -o jsonpath='{.spec.clusterIP}'
```

> **Note:** If using a custom namespace, ensure you update the namespace name in all subsequent steps.

---

## Step 2: Export the current OpenShiftDNS configuration

Dump the existing OpenShiftDNS configuration to a temporary file by running:

```bash
oc get dns.operator.openshift.io default \
  -o yaml > "<PATH_TO_curr_openshiftdns_config.yaml>"
```

This allows you to inspect and modify the configuration safely before applying it.

> **Note:** It is highly recommended to back up this file before proceeding so that, in case of failure, we can [rollback](#rollback-in-case-of-failure) to the original OpenShiftDNS configuration.

---

## Step 3: Inspect the current OpenShiftDNS upstream resolvers configuration

Copy the current OpenShiftDNS configuration file by running:

```bash
cp "<PATH_TO_curr_openshiftdns_config.yaml>" "<PATH_TO_gc_openshiftdns_config.yaml>"
```

Now, open the new Guardicore OpenShiftDNS configuration file and locate the `upstreamResolvers` under `specs` configuration, for example:

```bash
spec:
  upstreamResolvers:
    policy: Sequential
    upstreams:
    - type: SystemResolvConf
```

1. If the upstream resolvers target is type `SystemResolvConf`, replace it with:
    ```bash
    - type: Network
    address: <GC_DNS_PROXY_SERVICE_IP>
    port: 53
    ```
2. If the upstream resolvers target is not type `SystemResolvConf`, this means OpenShiftDNS is already forwarding to one or more explicit DNS servers and in this case:
    1. Update the Guardicore DNS Proxy configuration so it forwards to the same upstream DNS servers currently configured in OpenShiftDNS by running:
        ```bash
        helm upgrade gc-app k8s-charts/gc-kubernetes \
          --reuse-values \
          --set gc-dns-proxy.forwardTo="{<DNS_1>,<DNS_2>,<DNS_3>,...}"
        ```
    2. Force the `gc-dns-proxy` deployment to reload the updated configuration:
        ```bash
        oc -n guardicore rollout restart deployment gc-dns-proxy
        ```
    3. Verify that the `gc-dns-proxy` pods restart successfully and return to `Running` and fully `Ready` states:
        ```bash
        oc get pods -n guardicore
        ```
    4. Back to the current OpenShiftDNS configuration file, replace the upstream resolvers target with:
        ```bash
        - type: Network
        address: <GC_DNS_PROXY_SERVICE_IP>
        port: 53
        ```

---

## Step 4: Apply the updated OpenShiftDNS configuration

```bash
oc apply -f "<PATH_TO_gc_openshiftdns_config.yaml>"
```

Now, verify that the OpenShiftDNS pods restart successfully and return to `Running` and fully `Ready` states:
    ```bash
    oc get pods -n openshift-dns
    ```

---

## Step 5: Verify that traffic is reaching the Guardicore DNS Proxy

Verify that DNS queries are being forwarded through `gc-dns-proxy` by running:

```bash
oc run -it --rm debug --image=busybox --restart=Never -- \
  nslookup gc-dns-proxy.intercept.test
```

Expected output:

```
Server:    10.96.0.10
Address 1: 10.96.0.10 kube-dns.kube-system.svc.cluster.local

Name:      gc-dns-proxy.intercept.test
Address 1: 127.0.0.1
```

The `127.0.0.1` for `gc-dns-proxy.intercept.test` indicates that the query is being handled by gc-dns-proxy.

---

## Rollback in case of failure

If the OpenShiftDNS does not start correctly after the change, or if you need to revert for any reason, follow the steps below to restore the original configuration by running:

```bash
oc apply -f "<PATH_TO_curr_openshiftdns_config.yaml>"
```

Now, verify that the OpenShiftDNS pods restart successfully and return to `Running` and fully `Ready` states:
    ```bash
    oc get pods -n openshift-dns
    ```

---

## Support

For issues or questions, contact Akamai Customer Support.
