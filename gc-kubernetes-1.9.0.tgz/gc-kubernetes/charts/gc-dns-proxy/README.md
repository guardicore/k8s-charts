# Configure CoreDNS to Forward DNS Traffic via Guardicore DNS Proxy

This guide walks you through manually configuring the CoreDNS to forward DNS traffic through the Guardicore DNS Proxy on the following k8s cluster types:
1. on-prem
2. RKE2
3. EKS &mdash; _(**read [this](#eks-specific-notes) first**)_

For guides on other k8s cluster types:
1. [OpenShift](README.openshift.md)
2. [GKE](README.gke.md)

## Prerequisites

Before configuring the CoreDNS, ensure you have:

- **gc-kubernetes** Helm chart installed with `global.features.enforcement.fqdn.enabled` toggled to `true`
- **CoreDNS** deployment in the `kube-system` namespace

---

## EKS-specific notes

### Self-managed CoreDNS

Follow the steps in this guide.

### EKS managed CoreDNS add-on

Follow the steps in this guide.

> **Caveat:** Add-on upgrades may overwrite your CoreDNS changes unless you use `--resolve-conflicts PRESERVE` when upgrading:
> ```bash
> aws eks update-addon --cluster-name <CLUSTER_NAME> \
>   --addon-name coredns \
>   --resolve-conflicts PRESERVE
> ```

> **Recommendation:** Uninstall the managed add-on to avoid upgrade conflicts. EKS will deploy self-managed CoreDNS:
> ```bash
> aws eks delete-addon --cluster-name <CLUSTER_NAME> \
> --addon-name coredns
> ```

---

## Step 1: Get the ClusterIP of the Guardicore DNS Proxy service

Obtain the `<GC_DNS_PROXY_SERVICE_IP>` by running:

```bash
kubectl get service -n guardicore gc-dns-proxy \
  -o jsonpath='{.spec.clusterIP}'
```

> **Note:** If using a custom namespace, ensure you update the namespace name in all subsequent steps.

---

## Step 2: Inspect the CoreDNS deployment name and ConfigMap name

Different cluster types may use different names for the CoreDNS deployment and ConfigMap. Identify them by running:

```bash
kubectl get deployments -n kube-system
kubectl get configmaps -n kube-system
```

> **Note:** The deployment name (for example, `coredns` or `rke2-coredns`) and ConfigMap name (for example, `coredns` or `rke2-coredns`). You will use these as `<COREDNS_DEPLOYMENT_NAME>` and `<COREDNS_CONFIGMAP_NAME>` in the subsequent steps.

---

## Step 3: Export the current CoreDNS configuration

Dump the existing CoreDNS configuration to a temporary file by running:

```bash
kubectl get configmap -n kube-system <COREDNS_CONFIGMAP_NAME> \
  -o yaml > "<PATH_TO_curr_coredns_configmap.yaml>"
```

This allows you to inspect and modify the configuration safely before applying it.

> **Note:** It is highly recommended to back up this file before proceeding so that, in case of failure, we can [rollback](#rollback-in-case-of-failure) to the original CoreDNS configuration.

---

## Step 4: Inspect the current CoreDNS `forward` configuration

Copy the current CoreDNS configuration file by running:

```bash
cp "<PATH_TO_curr_coredns_configmap.yaml>" "<PATH_TO_gc_coredns_configmap.yaml>"
```

Now, open the current CoreDNS configuration file and locate the `Corefile`'s `forward` configuration, for example:

```bash
forward . /etc/resolv.conf
```

1. If the configured `forward` target is `/etc/resolv.conf`, replace it with:
    ```bash
    forward . <GC_DNS_PROXY_SERVICE_IP>
    ```
2. If the configured `forward` target is not `/etc/resolv.conf`, this means CoreDNS is already forwarding to one or more explicit DNS servers and in this case:
    1. Update the Guardicore DNS Proxy configuration so it forwards to the same upstream DNS servers currently configured in CoreDNS by running:
        ```bash
        helm upgrade gc-app k8s-charts/gc-kubernetes \
          --reuse-values \
          --set gc-dns-proxy.forwardTo="{<DNS_1>,<DNS_2>,<DNS_3>,...}"
        ```
    2. Force the `gc-dns-proxy` deployment to reload the updated configuration:
        ```bash
        kubectl -n guardicore rollout restart deployment gc-dns-proxy
        ```
    3. Verify that the `gc-dns-proxy` pods restart successfully and return to `Running` and fully `Ready` states:
        ```bash
        kubectl get pods -n guardicore
        ```
    4. Back to the current CoreDNS configuration file, replace the `forward` target configuration with:
        ```bash
        forward . <GC_DNS_PROXY_SERVICE_IP>
        ```

---

## Step 5: Apply the updated CoreDNS configuration

```bash
kubectl apply -f "<PATH_TO_gc_coredns_configmap.yaml>"
```

1. Force the CoreDNS to reload the updated configuration:
    ```bash
    kubectl -n kube-system rollout restart deployment <COREDNS_DEPLOYMENT_NAME>
    ```
2. Verify that the CoreDNS pods restart successfully and return to `Running` and fully `Ready` states:
    ```bash
    kubectl get pods -n kube-system
    ```

---

## Step 6: Verify that traffic is reaching the Guardicore DNS Proxy

Verify that DNS queries are being forwarded through `gc-dns-proxy` by running:

```bash
kubectl run -it --rm debug --image=busybox --restart=Never -- \
  nslookup gc-dns-proxy.intercept.test
```

Expected output:

```
Server:    10.96.0.10
Address 1: 10.96.0.10 kube-dns.kube-system.svc.cluster.local

Name:      gc-dns-proxy.intercept.test
Address 1: 127.0.0.1
```

The `127.0.0.1` for `gc-dns-proxy.intercept.test` indicates that the query is being handled by gc-dns-proxy.

---

## Rollback in case of failure

If the CoreDNS does not start correctly after the change, or if you need to revert for any reason, follow the steps below to restore the original configuration by running:

```bash
kubectl apply -f "<PATH_TO_curr_coredns_configmap.yaml>"
```

1. Force the CoreDNS to reload the updated configuration:
    ```bash
    kubectl -n kube-system rollout restart deployment <COREDNS_DEPLOYMENT_NAME>
    ```
2. Verify that the CoreDNS pods restart successfully and return to `Running` and fully `Ready` states:
    ```bash
    kubectl get pods -n kube-system
    ```

---

## Support

For issues or questions, contact Akamai Customer Support.
