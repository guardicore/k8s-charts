# Configure kube-dns to Forward DNS Traffic via Guardicore DNS Proxy

This guide walks you through manually configuring the kube-dns to forward DNS traffic through the Guardicore DNS Proxy on GKE.

## Prerequisites

Before configuring the kube-dns, ensure you have:

- **gc-kubernetes** Helm chart installed with `global.features.enforcement.fqdn.enabled` toggled to `true`

---

## Step 1: Get the ClusterIP of the Guardicore DNS Proxy service

Obtain the `<GC_DNS_PROXY_SERVICE_IP>` by running:

```bash
kubectl get service -n guardicore gc-dns-proxy \
  -o jsonpath='{.spec.clusterIP}'
```

> **Note:** If using a custom namespace, ensure you update the namespace name in all subsequent steps.

---

## Step 2: Export the current kube-dns configuration

Dump the existing kube-dns configuration to a temporary file by running:

```bash
kubectl get configmap -n kube-system kube-dns \
  -o yaml > "<PATH_TO_curr_kube-dns_configmap.yaml>"
```

This allows you to inspect and modify the configuration safely before applying it.

> **Note:** It is highly recommended to back up this file before proceeding so that, in case of failure, we can [rollback](#rollback-in-case-of-failure) to the original kube-dns configuration.

---

## Step 3: Inspect the current kube-dns `upstreamNameservers` configuration

Copy the current kube-dns configuration file by running:

```bash
cp "<PATH_TO_curr_kube-dns_configmap.yaml>" "<PATH_TO_gc_kube-dns_configmap.yaml>"
```

Now, open the current kube-dns configuration file and locate the `data`'s `upstreamNameservers` configuration, for example:

```bash
data:
  upstreamNameservers: |
  [
      "8.8.8.8", # Google Public DNS
      "1.1.1.1" # Cloudflare DNS
  ]
```

> **Note:** The default in GKE is an **empty** kube-dns configuration.

1. If the kube-dns configuration is empty or `upstreamNameservers` is not configured, fill it with:
    ```bash
    data:
      upstreamNameservers: |
        [
            "<GC_DNS_PROXY_SERVICE_IP>"
        ]
    ```
2. If the `upstreamNameservers` is configured, this means kube-dns is already forwarding to one or more explicit DNS servers and in this case:
    1. Update the Guardicore DNS Proxy configuration so it forwards to the same upstream DNS servers currently configured in kube-dns by running:
        ```bash
        helm upgrade gc-app k8s-charts/gc-kubernetes \
          --reuse-values \
          --set gc-dns-proxy.forwardTo="{<DNS_1>,<DNS_2>,<DNS_3>,...}"
        ```
    2. Force the `gc-dns-proxy` deployment to reload the updated configuration:
        ```bash
        kubectl -n guardicore rollout restart deployment gc-dns-proxy
        ```
    3. Verify that the `gc-dns-proxy` pods restart successfully and return to `Running` and fully `Ready` states:
        ```bash
        kubectl get pods -n guardicore
        ```
    4. Back to the current kube-dns configuration file, replace the `upstreamNameservers` configuration with:
        ```bash
        data:
          upstreamNameservers: |
            [
                "<GC_DNS_PROXY_SERVICE_IP>"
            ]
        ```

---

## Step 4: Apply the updated kube-dns configuration

```bash
kubectl apply -f "<PATH_TO_gc_kube-dns_configmap.yaml>"
```

1. Force the kube-dns to reload the updated configuration:
    ```bash
    kubectl -n kube-system rollout restart deployment kube-dns
    ```
2. Verify that the kube-dns pods restart successfully and return to `Running` and fully `Ready` states:
    ```bash
    kubectl get pods -n kube-system
    ```

---

## Step 5: Verify that traffic is reaching the Guardicore DNS Proxy

Verify that DNS queries are being forwarded through `gc-dns-proxy` by running:

```bash
kubectl run -it --rm debug --image=busybox --restart=Never -- \
  nslookup gc-dns-proxy.intercept.test
```

Expected output:

```
Server:    10.96.0.10
Address 1: 10.96.0.10 kube-dns.kube-system.svc.cluster.local

Name:      gc-dns-proxy.intercept.test
Address 1: 127.0.0.1
```

The `127.0.0.1` for `gc-dns-proxy.intercept.test` indicates that the query is being handled by gc-dns-proxy.

---

## Rollback in case of failure

If the kube-dns does not start correctly after the change, or if you need to revert for any reason, follow the steps below to restore the original configuration by running:

```bash
kubectl apply -f "<PATH_TO_curr_kube-dns_configmap.yaml>"
```

1. Force the kube-dns to reload the updated configuration:
    ```bash
    kubectl -n kube-system rollout restart deployment kube-dns
    ```
2. Verify that the kube-dns pods restart successfully and return to `Running` and fully `Ready` states:
    ```bash
    kubectl get pods -n kube-system
    ```

---

## Support

For issues or questions, contact Akamai Customer Support.
