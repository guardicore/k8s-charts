# CHANGELOG

### 1.9.0
- [GC-163707] Prepare for publishing v1.9.0 to public repo

### 1.8.17
- [GC-162363] Fix issues reported by the customer, and some other improvements
- [GC-160747] Add gc-kube-inventory Helm chart
- [GC-162365] Reduce k8s RBACs to minimal
- [GC-163599] Fix wrong apiGroup in gc-guest-agent's RBACs

### 1.8.16
- [GC-159902] adjust replica configuration and high availability for gc-dns-proxy

### 1.8.15
- [GC-151938] Add autoInject field for DaemonSet mode with DNS injector sidecar on managed platforms

### 1.8.14
- [GC-00000] fixing readme

### 1.8.13
- [GC-00000] Promoting the detailed README.md

### 1.8.11
- [GC-151908] add an automatic policy_propagation_delay_ms configuration based on CNI type

### 1.8.10
- [GC-155195] set gc-deployment entrypoint command

### 1.8.9
- [GC-155195] fail fast if root CA creation hook is failing

### 1.8.8
- [GC-154956] Add BPF mode support for reveal agent, and create a custom high-priority PriorityClass

### 1.8.7
- [GC-138287] Fix fqdn gc-dns-proxy ovn configurations

### 1.8.6
- [GC-128894] Add TLS support for FQDN HTTP endpoints with automatic CA generation and user-provided CA options
- [GC-135797] Add ServiceAccount authentication support for FQDN HTTP endpoints

### 1.8.5
- [GC-150830] Fix example-values.yaml field names and align sub-chart defaults

### 1.8.4
- [GC-128792] Add gc-dns-proxy metrics service
- [GC-144965] Export gc-dns-proxy configurations as advanced options
- [GC-122515] Docs – edit the k8s API certificate command in NOTES.txt

### 1.8.3
- [GC-144393] Add probes toggle configuration

### 1.8.2
- [GC-140323] Add kube-enforce fqdn ip storage configurations

### 1.8.1
- [GC-138287] Fix fqdn gc-dns-proxy conditions

### 1.8.0
- [GC-138287] Add fqdn gc-dns-proxy yamls

### 1.7.0
- [GC-137046] Improve enforcementCni logic #2
- [GC-138795] Move debug switch under global values
- [GC-138794] Minor tidy ups
- [GC-137571] Remove residual gc-guest-agent and gc-kube-enforce serviceAccount create field

### 1.6.0
- [GC-137679] Add extra envs to gc-kube-enforce
- [GC-137670] Tidy up values.yaml
- [GC-137571] Remove ServiceAccounts creation configurability
- [GC-137559] Improve http proxy configuration values validation
- [GC-137184] Improve aggregatorEndpoints validation logic
- [GC-137173] Hardcode gcProfile to default
- [GC-137046] Improve enforcementCni logic
- [GC-136808] Rename and improve public/private image registry logic
- [GC-136782] Improve appVersion logic

### 1.5.0
- [GC-136160] Support HTTP proxy configuration on GC guest-agent and kube-enforce

### 1.4.0
- [GC-136059] Replace sslServer and sslPort with sslAddresses and rename

### 1.3.0
- [GC-116152] Support reporting node info in kube-enforce

### 1.2.0
- [GC-125135] - Support SNAT visibility with Cilium eBPF IP Masquerading
                Specifically in the helm charts - mount /sys to /host/sys not only for amazonvpc CNI

### 1.1.0
- Removed the deprecated gc-kube-inventory chart
- Removed the deprecated notification port configuration

### 1.0.0
- First helm-chart release version
