{{- define "aggregatorEndpoints" -}}
{{- $aggregatorEndpoints := .Values.aggregatorEndpoints -}}
{{- if or ( not ( kindIs "slice" $aggregatorEndpoints ) ) ( eq ( len $aggregatorEndpoints ) 0 ) -}}
  {{- fail "aggregatorEndpoints must be a non-empty list" -}}
{{- end -}}
{{- join "," $aggregatorEndpoints -}}
{{- end -}}

{{- define "httpProxyEndpoint" -}}
{{- $httpProxyEndpointIP := .Values.global.features.httpProxy.ip -}}
{{- $httpProxyEndpointPort := .Values.global.features.httpProxy.port -}}
{{- if or ( eq $httpProxyEndpointIP "" ) ( eq $httpProxyEndpointPort "" ) -}}
  {{- fail "global.features.httpProxy.ip and global.features.httpProxy.port must be set" -}}
{{- end -}}
{{- printf "%s:%s" $httpProxyEndpointIP $httpProxyEndpointPort -}}
{{- end -}}

{{- define "enforcementCni" -}}
{{- if .Values.global.features.enforcement.enabled -}}
  {{- $enforcementCni := ( required "global.features.enforcement.cni must be set" .Values.global.features.enforcement.cni ) -}}
  {{- $supportedEnforcementCniList := list "calico" "ovn" "azurecni" "amazonvpc" "cilium" -}}
  {{- if not ( has $enforcementCni $supportedEnforcementCniList ) -}}
    {{- fail ( printf "Unsupported enforcement CNI: %s" $enforcementCni ) -}}
  {{- end -}}
  {{- $enforcementCni -}}
{{- end -}}
{{- end -}}

{{- define "gcImageRegistry" -}}
{{- $gcImageRegistry := ( ternary .Values.gcPublicImageRegistry .Values.global.gcPrivateImageRegistry .Chart.IsRoot ) -}}
{{- $gcImageRegistryPath := ( ternary "gcPublicImageRegistry" "global.gcPrivateImageRegistry" .Chart.IsRoot ) -}}
{{- required ( printf "%s must be set" $gcImageRegistryPath ) $gcImageRegistry -}}
{{- end -}}

{{- define "imageTag" -}}
{{- $imageTag := ( .Values.appVersion | default .Values.global.appVersion ) -}}
{{- $appVersionPath := ( ternary "appVersion" ( printf "%s.appVersion" .Chart.Name ) .Chart.IsRoot ) -}}
{{- required ( printf "At least one of %s or global.appVersion must be set" $appVersionPath ) $imageTag -}}
{{- end -}}

{{- define "debug" -}}
{{- if hasKey .Values "debug" -}}
  {{- .Values.debug -}}
{{- else -}}
  {{- .Values.global.debug -}}
{{- end -}}
{{- end -}}
